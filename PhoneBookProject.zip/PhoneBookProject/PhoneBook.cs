using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneBookProject
{
    public class PhoneBook
    {
        public List<Contact> contacts = new List<Contact>();

        public string getString(string message)
        {
            Console.WriteLine(message);
            return Console.ReadLine();

        }

        public int getInt(string message)
        {
            Console.WriteLine(message);
            return Convert.ToInt32(Console.ReadLine());

        }
        public void newContact()
        {
            Contact c = new Contact();
            c.id = getInt("Whats ID?");
            c.name = getString("Whats name?");
            c.surname = getString("Whats surname?");
            c.city = getString("Whats city?");
            c.numbers = new List<int>();
            c.numbers.Add(getInt("Contact Number?"));
            contacts.Add(c);
        }

        public void getContacts()
        {
            contacts.ForEach(c =>
            {
                Console.WriteLine(c.id + " " + c.name + " " + c.surname + " " + c.city);
                c.numbers.ForEach(n => Console.WriteLine(n));
            });
        }

        public void getContact(int id)
        {
            if (contacts.Any(c => c.id == id)) {
                contacts.FindAll(c => c.id == id).ForEach(c =>
                {
                    Console.WriteLine(c.id + " " + c.name + " " + c.surname + " " + c.city);
                    c.numbers.ForEach(n => Console.WriteLine(n));
                });
            }

            else
            {
                Console.WriteLine("There's no contact with that ID.");
            }

        }

        public void getContacts(string city)
        {
            if (contacts.Any(c => c.city == city))
            {
                contacts.FindAll(c => c.city == city).ForEach(c =>
                {
                    Console.WriteLine(c.id + " " + c.name + " " + c.surname + " " + c.city);
                    c.numbers.ForEach(n => Console.WriteLine(n));
                });
            }

            else
            {
                Console.WriteLine("There's no contact with that city.");
            }
        }

        public void deleteContact(int id)
        {
            contacts.Remove(contacts.Find(c => c.id == id));
        }

        public void addNumber(int id, int number)
        {
            if (contacts.Any(c => c.id == id))
            {
                contacts.Find(c => c.id == id).numbers.Add(number);

            }

            else
            {
                Console.WriteLine("No contact with this ID.");
            }
        }

    }
}

using System;

namespace PhoneBookProject
{
    public class Program
    {
        static void Main(string[] args)
        {
            PhoneBook pb = new PhoneBook();
            pb.newContact();
            pb.newContact();
            pb.newContact();

            pb.addNumber(1, 536973);

            pb.getContacts();
            Console.WriteLine("*******************");

            pb.getContact(1);
            Console.WriteLine("*******************");

            pb.getContact(9);
            Console.WriteLine("*******************");

            pb.getContacts("Ankara");
            Console.WriteLine("*******************");

            pb.getContacts("Bursa");
            Console.WriteLine("*******************");

            pb.deleteContact(3);
            pb.getContacts();
            Console.WriteLine("*******************");

        }
    }
}
